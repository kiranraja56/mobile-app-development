package com.example.assignmentt;


import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class splashactivty extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.splashactivity);
        Thread mSplashThread = new Thread() {
            @Override
            public void run() {
                try{
                    synchronized (this){

                        wait(2000);
                    }
                } catch (InterruptedException ignored) {

                }
                finally {
                    startActivity(new Intent(getApplicationContext(),homescreen.class));
                    finish();
                }
            }
        };

        mSplashThread.start();
    }
}
