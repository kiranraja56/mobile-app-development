package com.example.assignmentt;



import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class homescreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.homescreen);
        Button getStartedButton = findViewById(R.id.btn_getstarted);
        getStartedButton.setOnClickListener(v -> {

            Intent intent = new Intent(homescreen.this, loginactivty.class);
            startActivity(intent);

        });
    }

}

