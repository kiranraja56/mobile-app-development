package com.example.assignment;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

    public class MainActivity extends AppCompatActivity {

        private static final String TAG = "Lifecycle";
        EditText inputText;
        Button goToSecondActivity, openWebPage;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            Log.d(TAG, "onCreate called");

            inputText = findViewById(R.id.editText);
            goToSecondActivity = findViewById(R.id.buttonNavigate);
            openWebPage = findViewById(R.id.buttonOpenWeb);

            goToSecondActivity.setOnClickListener(v -> {
                String text = inputText.getText().toString();
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("user_input", text);
                startActivity(intent);
            });

            openWebPage.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
                startActivity(intent);
            });
        }

        @Override
        protected void onStart() { super.onStart(); Log.d(TAG, "onStart called"); }

        @Override
        protected void onResume() { super.onResume(); Log.d(TAG, "onResume called"); }

        @Override
        protected void onPause() { super.onPause(); Log.d(TAG, "onPause called"); }

        @Override
        protected void onStop() { super.onStop(); Log.d(TAG, "onStop called"); }

        @Override
        protected void onDestroy() { super.onDestroy(); Log.d(TAG, "onDestroy called"); }
    }

