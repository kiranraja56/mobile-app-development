package com.example.assignment;



import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private static final String TAG = "Lifecycle";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Log.d(TAG, "onCreate called");

        TextView textView = findViewById(R.id.textView);
        String receivedText = getIntent().getStringExtra("user_input");
        textView.setText(receivedText);
    }

    @Override
    protected void onStart() { super.onStart(); Log.d(TAG, "onStart called"); }

    @Override
    protected void onResume() { super.onResume(); Log.d(TAG, "onResume called"); }

    @Override
    protected void onPause() { super.onPause(); Log.d(TAG, "onPause called"); }

    @Override
    protected void onStop() { super.onStop(); Log.d(TAG, "onStop called"); }

    @Override
    protected void onDestroy() { super.onDestroy(); Log.d(TAG, "onDestroy called"); }
}
