package com.example.assignmentt;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class loginactivty extends AppCompatActivity {
    private TextView signupTextView;
    private EditText user_email, password;
    private Button loginbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_loginactivity);

        user_email = findViewById(R.id.useremail);
        password = findViewById(R.id.password);
        signupTextView = findViewById(R.id.signup_text);
        loginbutton = findViewById(R.id.login_button);

        // Redirect to sign-up page when "Sign up" text is clicked
        signupTextView.setOnClickListener(view -> {
            Intent intent = new Intent(loginactivty.this, signupactivty.class);
            startActivity(intent);
            finish();
        });

        loginbutton.setOnClickListener(view -> {
            String email = user_email.getText().toString().trim();
            String pass = password.getText().toString().trim();

            if (!validateInputs(email, pass)) {
                return;
            }

            loginUser(email, pass);
        });
    }

    private boolean validateInputs(String email, String pass) {
        if (email.isEmpty()) {
            user_email.setError("Email is required");
            user_email.requestFocus();
            return false;
        }
        if (pass.isEmpty()) {
            password.setError("Password is required");
            password.requestFocus();
            return false;
        }
        if (pass.length() < 6) {
            password.setError("Password must be at least 6 characters");
            password.requestFocus();
            return false;
        }
        return true;
    }

    private void loginUser(String email, String pass) {
        // Simple hardcoded credentials for login
        String correctEmail = "admin@example.com";
        String correctPassword = "123456";

        if (email.equals(correctEmail) && pass.equals(correctPassword)) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(loginactivty.this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid email or password", Toast.LENGTH_LONG).show();
        }
    }
}
